package Grade;

public interface ScoreManage {
	public void input();
	public void delete();
	public void edit();
	public void print();
	public void exit();
}
