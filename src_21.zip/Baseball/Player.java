package baseball;

public class Player implements Comparable<Player>{
	private String club;
	private String name;
	private int salary;
	
	public Player(String club, String name, int salary) {
		this.club = club;
		this.name = name;
		this.salary = salary;
	}
	
	public void setClub(String club) {
		this.club = club;
	}
	public String getName() {
		return name;
	}
	public String getClub() {
		return club;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public int compareTo(Player o) {
		return name.compareTo(o.getName());
	}
}









