package baseball;
import java.util.Hashtable;

public interface BaseBallPro {
	public void input(Player p);
	public Hashtable<String, Player> output(String name);
	public void trade(String club, Player p);
	public void edit(Player p);
	public void delete(Player p);
	public void exit();
	public boolean isClub(String club);
	public Player getPlayer(String club, String name);
}
