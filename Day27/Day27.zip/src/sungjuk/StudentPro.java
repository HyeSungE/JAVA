package sungjuk;

import javax.swing.JTextArea;

public interface StudentPro {
	public void input();
	public void output(JTextArea jta);
	public void edit();
	public void delete();
	public void exit();
}
