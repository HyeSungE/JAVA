package RentCarProgrm;
import java.sql.*;
import java.util.*;

public class DAO {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	
	private String url,user,pass;
	
	public DAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.err.println("����Ŭ ����̹� ���� ����");
		}
		url = "jdbc:oracle:thin:@localhost:1521:xe";
		user = "bigdata01"; pass = "bigdata01";
	}
	//ȸ��
	public class memDAO {
		public memDAO() {
			try {
				con = DriverManager.getConnection(url, user, pass);
			}catch(SQLException e){}
		}
		public boolean checkAcc(String id,String pw) { //����Ȯ��
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from memTable where memId = ? and memPw = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1,id); ps.setString(2,pw);
				rs=ps.executeQuery();
				ArrayList<member> list = makeArrayList(rs);
				
				if(list.size()>0) {
					System.out.println("����!!!!!");
					return true;
				}
				else if(list.size()==0) {
					System.out.println("����!!!!!");
					return false;
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		public boolean checkId(String id) { //���̵� �ߺ�Ȯ��
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from memTable where memId = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1, id); 
				rs=ps.executeQuery();
				ArrayList<member> list = makeArrayList(rs);
				if(list.size()>0) {
					System.out.println("2����!!!!!");
					return false;
				}
				else if(list.size()==0) {
					System.out.println("2����!!!!!");
					return true;
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		public int insertMember(member m) { //ȸ�����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "insert into memTable values(memSeq.nextVal,?,?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setString (1,m.getName());
				ps.setString(2,m.getId());
				ps.setString(3,m.getPw());
				ps.setString(4,m.getEmail());
				ps.setString(5,m.getTel());
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("insert ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		
		public ArrayList<member> makeArrayList(ResultSet rs) throws SQLException {
			ArrayList<member> list = new ArrayList<>();
			while(rs.next()) {
				int n = rs.getInt("num");
				String name = rs.getString("memName");
				String id = rs.getString("memId");
				String pw = rs.getString("memPw");
				String email = rs.getString("memEm");
				String tel = rs.getString("memTel");
				member member = new member(name, id,pw,email,tel);
				member.setNum(n);
				list.add(member);
			}
			return list;
		}
	}
	//����
	public class carDAO{
		public carDAO() {
			try {
				con = DriverManager.getConnection(url, user, pass);
			}catch(SQLException e){}
		}
		//�������
		public int insertCar(car c) {
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "insert into carTable values(carSeq.nextVal,?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setString (1,c.getName());
				ps.setString(2,c.getCarNum());
				ps.setInt(3,c.getPrice());
				ps.setString(4,c.getRentStat());
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("insert ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		//�����԰����� -> �뿩 ���� ����
		//���� ����
		public int deleteCar(String carNum) {//������ȣ�� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "delete from carTable where CARNUM = ?";
				ps = con.prepareStatement(sql);
				ps.setString (1,carNum);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("deleteCar ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public int deleteCar(int num) {//num(����)���� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "delete from carTable where NUM = ?";
				ps = con.prepareStatement(sql);
				ps.setInt (1,num);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("deleteCar ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public int UpdateRentStat(int num,String carRentStat) {//num(����)���� ������ ��Ʈ���� ���θ� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql=new String();
				if(carRentStat.equals("����")) 
					sql = "update carTable set carRentStat='�Ұ���' where NUM = ?";
				else	
					sql = "update carTable set carRentStat='����' where NUM = ?";
				ps = con.prepareStatement(sql);
				ps.setInt (1,num);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("UpdateRentStat ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public boolean checkCarNum(String carNum) { //���� ��ȣ �ߺ�Ȯ��
			
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from carTable where carNum = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1, carNum);
				ps.executeQuery();
				rs=ps.executeQuery();
				ArrayList<car> list = makeArrayList(rs);
				if(list.size()>0) {
					System.out.println("����!!!!!");
					return false;
				}
				else if(list.size()==0) {
					System.out.println("����!!!!!");
					return true;
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		
		public ArrayList<car> makeArrayList(ResultSet rs) throws SQLException {
			ArrayList<car> list = new ArrayList<>();
			while(rs.next()) {
				int n = rs.getInt("num");
				String carName = rs.getString("carName");
				String carNum = rs.getString("carNum");
				int carPrice = rs.getInt("carPrice");
				String carRentStat = rs.getString("carRentStat");
				car car = new car(carName, carNum,carPrice,carRentStat);
				car.setNum(n);
				list.add(car);
				System.out.println(list.size());
			}
			return list;
		}
		public ArrayList<car> list(){
			ArrayList<car> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from carTable";
				ps=con.prepareStatement(sql);
				rs=ps.executeQuery();
				while(rs.next()) {
					int n = rs.getInt("num");
					String name = rs.getString("carName");
					String carNum = rs.getString("carNum");
					int price = rs.getInt("carPrice");
					String rentStat = rs.getString("carRentStat");
					car car = new car(name, carNum,price,rentStat);
					car.setNum(n);
					list.add(car);
					//System.out.println(list.size());
				}
				
			}catch(Exception e) {}
			return list;
		}
	}
}
