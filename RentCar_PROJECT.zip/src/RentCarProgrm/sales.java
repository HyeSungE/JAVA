package RentCarProgrm;

public class sales {
	int num;
	int price;
	
	public sales(int num,int price) {
		this.num=num;
		this.price=price;
	}
}
