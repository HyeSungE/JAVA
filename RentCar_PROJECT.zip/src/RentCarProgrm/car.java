package RentCarProgrm;

public class car {
	private int num;
	private String name;
	private String carNum;
	private int price;
	private String rentStat;
	public car(String name, String carNum,
			int price,String rentStat) {
		this.name=name;
		this.carNum=carNum;
		this.price=price;
		this.rentStat=rentStat;
	}
	public int getNum() {
		return this.num;
	}
	public String getName() {
		return this.name;
	}
	public String getCarNum() {
		return this.carNum;
	}
	public int getPrice() {
		return this.price;
	}
	public String getRentStat() {
		return this.rentStat;
	}
	public void setNum(int num) {
		this.num=num;
	}
	
}
