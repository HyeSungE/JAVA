package RentCarProgrm;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
public class SearchByDay_dlg extends Dialog implements ActionListener {
	private Calendar cal = Calendar.getInstance();
	private Label lb = new Label("", Label.CENTER);
	private Button left_bt = new Button(" �� ");
	private Button right_bt = new Button(" �� ");
	private Label[] week_lb = new Label[7];
	private String[] str = new String[] {"��","��","ȭ","��","��","��","��"};
	private Button[] day_bt = new Button[42];
	private int year, month;
	private Panel North_p = new Panel();
	private Panel Center_p = new Panel();
	private Button can_bt = new Button("�� ��");
	private int lastDay=0,week=0;
	private void init() {
		//���̾ƿ� ����
		this.add("North", North_p);
		this.add("Center", Center_p);
		North_p.setLayout(new BorderLayout());
		Center_p.setLayout(new GridLayout(7,7));
		//label ����
		lb.setText(year+"�� " + month + "��");
		lb.setFont(new Font("", Font.BOLD, 30));		
		//������Ʈ �߰�
		North_p.add("West", left_bt);	
		North_p.add("Center", lb);
		North_p.add("East", right_bt);
		this.add("South",can_bt);
		//��ư�̺�Ʈ �߰�
		right_bt.addActionListener(this);
		left_bt.addActionListener(this);
		can_bt.addActionListener(this);
		
		for(int i=0; i<week_lb.length; ++i) {
			week_lb[i] = new Label(str[i], Label.CENTER);
			Center_p.add(week_lb[i]);
		}
		for(int i=0; i<day_bt.length; ++i) {
			day_bt[i] = new Button("");
			Center_p.add(day_bt[i]);
		}
		buttonSetting();

	}
	public void buttonSetting() {
		for(int i=0; i<day_bt.length; ++i) {
			day_bt[i].setLabel("");
			day_bt[i].setEnabled(true);
		}
		
		week = cal.get(Calendar.DAY_OF_WEEK);
		lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		int co = 0;	
		for(int i=1; i<week; ++i) {
			day_bt[co].setLabel("");
			day_bt[co].setEnabled(false);
			co++;
		}
		for(int i=1; i<=lastDay; ++i) {
			day_bt[co].setLabel(String.valueOf(i));
			//��¥ ��ư�� ���콺 �̺�Ʈ �߰�
			day_bt[co].addActionListener(this);
			co++;
		}
		for ( ; co<day_bt.length; ++co) {
			day_bt[co].setLabel("");
			day_bt[co].setEnabled(false);
		}
	}

	public SearchByDay_dlg(Frame owner,String title, boolean modal) {
		super(owner,title, modal);
		year = cal.get(Calendar.YEAR);
		month = cal.get(Calendar.MONTH) + 1;
		cal.set(Calendar.DAY_OF_MONTH, 1);
		init();
		super.setSize(300,300);
		Dimension screen = 
				Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2 - super.getWidth()/2);
		int ypos = (int)(screen.getHeight()/2 - super.getHeight()/2);
		super.setLocation(xpos, ypos);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//��¥ ��ư�� ������ , �ش� ��¥ ���ķ� ���� ������ ������ �����ִ� ���̾�α� ȣ��
		for(int i=week;i<=lastDay;i++) {	
			if(e.getSource()==day_bt[week]) {
				//
			}
		}
		//�� ���� ��ư
		if(e.getSource()==right_bt||e.getSource()==left_bt) {
			if (e.getSource()==left_bt) {
				month--;
				if (month<1) {
					month = 12;
					year--;
				}
			}else if (e.getSource()==right_bt) {
				month++;
				if (month>12) {
					month = 1;
					year++;
				}
			}
			lb.setText(year+"�� " + month + "��");
			cal.set(year, month-1, 1);
			buttonSetting();
		}
		//��� ��ư�� ������ , ���̾�α� ����
		else if(e.getSource()==can_bt) {
			this.setVisible(false);
		}
		
		
		
	}
	
}
