package RentCarProgrm;

public class member {
	private int num;
	private String name;
	private String id;
	private String pw;
	private String email;
	private String tel;
	public member(String name,String id,
	String pw,String email,String tel) {
		this.name=name;
		this.id=id;
		this.pw=pw;
		this.email=email;
		this.tel=tel;
	}
	public String getName() {
		return this.name;
	}
	public String getId() {
		return this.id;
	}
	public String getPw() {
		return this.pw;
	}
	public String getEmail() {
		return this.email;
	}
	public String getTel() {
		return this.tel;
	}
	public void setNum(int num) {
		this.num=num;
	}
}
