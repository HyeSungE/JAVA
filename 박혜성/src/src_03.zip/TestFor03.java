
public class TestFor03 {
	public static void main(String[] args) {
		int odd = 0, even = 0;
		for(int i=1; i<=100; ++i) {
			if (i%2 == 0) {
				even += i;
			}else {
				odd += i;
			}
		}
		
		System.out.printf("Ȧ���� \t�� : %d\n¦���� �� : %d\n\\", odd, even);
	}
}
