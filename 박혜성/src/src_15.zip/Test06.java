import java.awt.*;

class MyFrame06 extends Frame{
	private Dialog dlg = new Dialog(this, "���!!", true);
	private Label lb = new Label("����Դϴ�!!", Label.CENTER);
	
	public void init() {
		dlg.setLayout(new BorderLayout());
		dlg.add("Center", lb);
	}
	public MyFrame06(String title) {
		super(title);
		this.init();
		
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		//dlg.setSize(300,150);
		//dlg.setLocation(xpos, ypos);
		dlg.setBounds(xpos, ypos, 300, 150);
		//setLocation + setSize => �տ� 2�ڸ��� ������ġ, �ڿ� 2�ڸ��� ũ��
		dlg.setVisible(true);
	}
}

public class Test06 {
	public static void main(String[] args) {
		MyFrame06 mf = new MyFrame06("frame����");
	}
}
