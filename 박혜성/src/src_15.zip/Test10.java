import java.awt.*;

class MyFrame10 extends Frame{
	private Label nor_lb = new Label("�����Է�");
	
	private Label cen_west_lb[] = new Label[9];
	private String str[] = new String[] {"��  ��", "��  ��", "��  ��", 
				"��  ��", "��  ��", "��  ��","��  ��","��  ȸ","��  ��"};
	private TextField num_tf = new TextField();
	private TextField name_tf = new TextField();
	private Choice ch = new Choice();
	private CheckboxGroup cg = new CheckboxGroup();
	private Checkbox m_cb = new Checkbox("��", cg, true);
	private Checkbox w_cb = new Checkbox("��", cg, false);
	private TextField kor_tf = new TextField();
	private TextField mat_tf = new TextField();
	private TextField eng_tf = new TextField();
	private TextField so_tf = new TextField();
	private TextField si_tf = new TextField();
	
	
	private Label cen_east_lb = new Label("��  ��");
	private TextArea cen_east_ta = new TextArea();
	
	private Button bt1 = new Button("����");
	private Button bt2 = new Button("�����");
	private Button bt3 = new Button("���� List");
	private Button bt4 = new Button("����");
	private Label sou_p_cen_lb = new Label("���� List ���");
	private TextArea sou_p_cen_ta = new TextArea();
		
	private Panel cen_p = new Panel();
	private Panel cen_west_p = new Panel();
	private Panel sex_p = new Panel();
	private Panel cen_west[] = new Panel[9];
	private Panel cen_east_p = new Panel();
	
	private Panel sou_p = new Panel();
	private Panel sou_p_bt = new Panel();
	private Panel sou_p_cen = new Panel();
	
	
	
	public void init() {
		this.setLayout(new BorderLayout());
		nor_lb.setFont(new Font("", Font.PLAIN, 30));
		this.add("North", nor_lb);
		
		this.add("Center", cen_p);
		cen_p.setLayout(new GridLayout(1,2));
		cen_p.add(cen_west_p);
		cen_west_p.setLayout(new GridLayout(9, 1));
		for(int i=0; i<9; ++i) {
			cen_west[i] = new Panel();
			cen_west_p.add(cen_west[i]);
			cen_west[i].setLayout(new BorderLayout());
			cen_west_lb[i] = new Label(str[i], Label.CENTER);
			cen_west_lb[i].setFont(new Font("", Font.PLAIN, 20));
			cen_west[i].add("West", cen_west_lb[i]);
		}
		cen_west[0].add("Center", num_tf);
		cen_west[1].add("Center", name_tf);
		cen_west[2].add("Center", ch);
		ch.add("�濵�а�");
		ch.add("��ǻ�Ͱ��а�");
		ch.add("�ɸ��а�");
		cen_west[3].add("Center", sex_p);
		sex_p.setLayout(new GridLayout(1,2));
		sex_p.add(m_cb);
		sex_p.add(w_cb);
		cen_west[4].add("Center", kor_tf);
		cen_west[5].add("Center", mat_tf);
		cen_west[6].add("Center", eng_tf);
		cen_west[7].add("Center", so_tf);
		cen_west[8].add("Center", si_tf);
		
		cen_p.add(cen_east_p);
		cen_east_p.setLayout(new BorderLayout());
		cen_east_lb.setFont(new Font("", Font.PLAIN, 25));
		cen_east_p.add("North", cen_east_lb);
		cen_east_p.add(cen_east_ta);
		
		this.add("South", sou_p);
		sou_p.setLayout(new BorderLayout());
		sou_p.add("North", sou_p_bt);
		sou_p.add("Center", sou_p_cen);
		sou_p_bt.setLayout(new FlowLayout(FlowLayout.LEFT));
		sou_p_bt.add(bt1);
		sou_p_bt.add(bt2);
		sou_p_bt.add(bt3);
		sou_p_bt.add(bt4);
		sou_p_cen.setLayout(new BorderLayout());
		sou_p_cen_lb.setFont(new Font("", Font.PLAIN, 25));
		sou_p_cen.add("North", sou_p_cen_lb);
		sou_p_cen.add(sou_p_cen_ta);
	}
	public MyFrame10(String title) {
		super(title);
		this.init();
		this.setSize(400,800);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
	}
}

public class Test10 {
	public static void main(String[] args) {
		MyFrame10 mf = new MyFrame10("frame����");
	}
}
