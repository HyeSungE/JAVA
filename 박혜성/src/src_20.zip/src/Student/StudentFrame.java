package Student;

import java.awt.*;
import java.awt.event.*;
import java.util.Collections;
import java.util.List;

import javax.swing.*;

public class StudentFrame extends JFrame implements ActionListener{
	private JToolBar jtb = new JToolBar();
	private JButton jbt1 = new JButton("�Է�");
	private JButton jbt2 = new JButton("����");
	private JButton jbt3 = new JButton("����");
	private JTabbedPane jtp = new JTabbedPane();
	private JPanel jp[] = new JPanel[4];
	private JTextArea jta[] = new JTextArea[4];
	//jta[0] => �̸�, jta[1] => ����, jta[2] => ����, jta[3] => ����
		
	private String[] str = new String[] {"�̸�", "����", "����", "����"};
	private MyInputDialog md = new MyInputDialog(this, "�л��Է�", true);
	
	private String title_str = new String(
			"�� �� �� ��\n"
		   +"-------------------------------------------------------------------------\n"
		   +"�̸�\t����\t����\t����\n"
		   +"-------------------------------------------------------------------------\n");
	private Panel p = new Panel();
	
	private StudentPro pro = new StudentProImpl();
	
	public void view_ta() {
		for(int i=0; i<jp.length; ++i) {
			List<Student> list = pro.output(str[i]);
			jta[i].setText(title_str);
			for(Student st : list) {
				jta[i].append(st.getName()+"\t");
				jta[i].append(st.getKor()+"\t");
				jta[i].append(st.getEng()+"\t");
				jta[i].append(st.getTot()+"\n");
			}
		}
	}
	
	
	public void init() {
		Container con = this.getContentPane();
		con.setLayout(new BorderLayout());
		con.add("North", jtb);
		jtb.add(jbt1);	jbt1.addActionListener(this);
		jtb.add(jbt2);	jbt2.addActionListener(this);
		jtb.add(jbt3);	jbt3.addActionListener(this);
		con.add("Center", jtp);
		for(int i=0; i<jp.length; ++i) {
			jp[i] = new JPanel();
			jp[i].setLayout(new BorderLayout());
			jta[i] = new JTextArea(title_str);
			jp[i].add("Center", jta[i]);
			jtp.add(str[i], jp[i]);
		}
		md.ok_bt.addActionListener(this);
	}
	
	public StudentFrame(String title) {
		super(title);
		this.init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==jbt1) {
			md.setVisible(true);
		}/*else if (e.getSource()==bt2) {

		}else if (e.getSource()==bt3) {
			
		}else if (e.getSource()==bt4) {
			System.exit(0);
		}*/else if (e.getSource()==md.ok_bt) {
			String name = md.getName();
			int kor = md.getKor();
			int eng = md.getEng();
			pro.input(name, kor, eng);
			md.clearData();
			md.setVisible(false);
			view_ta();
		}/*else if (e.getSource()==md.cen_bt) {
			md.clearData();
			md.setVisible(false);
		}*/
	}
	
	
	public static void main(String[] args) {
		new StudentFrame("��������");
	}
}
