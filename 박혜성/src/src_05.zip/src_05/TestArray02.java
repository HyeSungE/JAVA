
public class TestArray02 {
	public static void main(String[] args) {
		int arr1[];
		arr1 = new int[3];
		int arr2[] = new int[3];
		for(int i=0; i<arr2.length; ++i) {
			System.out.println("arr2[" + i +"] = " + arr2[i]);
			//�ʱⰪ ������ 0, �Ǽ��� 0.0, ������ false�� ����
		}
		/*
		int arr3[] = new int[] {1,2,3};
		int arr4[] = new int[] {1,2,2,23,34,3,43,3,23,3,3,3,4,4,6,78,67,5,34,6,6,4,5,43,5,6,7,6,5,67,7,56,5,6,7,8,6,5,6,7,8};
		System.out.println("arr4�� ���� : " + arr4.length);
		
		int arr5[] = {1, 2, 3, 4};
		for(int i=0; i<arr5.length; ++i) {
			System.out.println("arr5[" + i +"] = " + arr5[i]);
		}
		int arr6[];
		arr6 = new int[]{1, 2, 3};
		*/
	}
}














