import java.util.*;

public class TestArray04 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int arr[] = new int[10];
		int sum = 0;
		for(int i=0; i<arr.length; ++i) {
			System.out.print(i+1+"��° ���� �Է� : ");
			arr[i] = in.nextInt();
			sum += arr[i];
		}
		
		System.out.print("�Է��� �� : ");
		for(int i=0; i<arr.length-1; ++i) {
			System.out.print(arr[i] + ", ");
		}
		System.out.println(arr[arr.length-1]);
		
		System.out.printf("�Է��Ͻ� ���� �� : %d, ��հ� : %.2f\n"
									,sum, sum/(float)arr.length);
	}
}









