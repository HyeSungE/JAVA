import java.util.*;

public class TestArray07 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int arr[] = new int[10];
		for(int i=0; i<arr.length; ++i) {
			System.out.print(i+1+"��° ���� �Է� : ");
			arr[i] = in.nextInt();
		}
		int oddArr[] = new int[10];		//Ȧ���迭
		int evenArr[] = new int[10];	//¦���迭
		int oddSu=0, evenSu=0;			//�迭�� ��ġ
		
		for(int i=0; i<arr.length; ++i) {
			if (arr[i] % 2 == 0) {
				evenArr[evenSu] = arr[i];
				evenSu++;
			}else {
				oddArr[oddSu] = arr[i];
				oddSu++;
			}
		}
		
		System.out.print("Ȧ�� : ");
		for(int i=0; i<oddSu; ++i) {
			System.out.print(oddArr[i] + "\t");
		}
		System.out.println();
		
		System.out.print("¦�� : ");
		for(int i=0; i<evenSu; ++i) {
			System.out.print(evenArr[i] + "\t");
		}
	}
}










	
