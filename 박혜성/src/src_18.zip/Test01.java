import java.awt.*;
import java.awt.event.*;
class MyImageButton01 extends Button{
	private Image img;
	public MyImageButton01(Image img) {
		this.img = img;
	}
	public void setImg(Image img) {
		this.img = img;
	}
	public void paint(Graphics g) {
		g.drawImage(img, 5, 5, this.getWidth()-10, this.getHeight()-10, this);
	}
}

class MyFrame01 extends Frame implements ActionListener, Runnable{
	private MyImageButton01 mib[] = new MyImageButton01[9];
	
	private Label score_lb = new Label("���� : 00��", Label.CENTER);
	private Label time_lb = new Label("�ð� : 10��", Label.CENTER);
	private Button start_bt = new Button("����");
	private Button exit_bt = new Button("����");
	
	private Panel p = new Panel();
	private Panel east_p = new Panel();
	
	private boolean isEnable = false;
	private int co = 0;
	private int time = 10;
	private int num[] = new int[9];
	private int checkNum = 1;
		
	public void init() {
		this.setLayout(new BorderLayout());
		this.add("Center", p);
		p.setLayout(new GridLayout(3, 3));
		for(int i=0; i<mib.length; ++i) {
			mib[i] = new MyImageButton01(null);
			mib[i].addActionListener(this);
			p.add(mib[i]);
		}
		this.add("East", east_p);
		east_p.setLayout(new GridLayout(4, 1));
		east_p.add(score_lb);
		east_p.add(time_lb);
		east_p.add(start_bt);	start_bt.addActionListener(this);
		east_p.add(exit_bt);	exit_bt.addActionListener(this);
		buttonSetting();
	}
	
	public void buttonSetting() {
		start_bt.setEnabled(!isEnable);
		exit_bt.setEnabled(!isEnable);
		for(int i=0; i<mib.length; ++i) {
			mib[i].setEnabled(isEnable);
		}
	}
	
	public MyFrame01(String title) {
		super(title);
		init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
	}

	public void randomSetting() {
		for(int i=0; i<num.length; ++i) {
			num[i] = (int)(Math.random()*9) + 1;
			for(int j=0; j<i; ++j) {
				if (num[i] == num[j]) {
					i--;
					break;
				}
			}
		}
		for(int i=0; i<num.length; ++i) {
			Image img = Toolkit.getDefaultToolkit().getImage("img/"+num[i]+".png");
			mib[i].setImg(img);
			mib[i].repaint();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==start_bt) {
			co = 0;
			time = 10;
			checkNum = 1;
			score_lb.setText("���� : 0"+co+"��");
			time_lb.setText("�ð� : "+time+"��");
			isEnable = true;
			buttonSetting();
			Thread th = new Thread(this);
			th.start();
			randomSetting();
		}else if (e.getSource()==exit_bt) {
			System.exit(0);
		}else {
			for(int i=0; i<mib.length; ++i) {
				if (e.getSource()==mib[i]) {
					if (checkNum == num[i]) {
						co++;
						if (co<10) {
							score_lb.setText("���� : 0"+co+"��");
						}else {
							score_lb.setText("���� : "+co+"��");
						}						
						checkNum++;
						mib[i].setEnabled(false);
						if (checkNum>9) {
							randomSetting();
							checkNum = 1;
							for(int j=0; j<mib.length; ++j) {
								mib[j].setEnabled(true);
							}
						}
					}
				}
			}
		}
	}
	
	public void buttonClear() {
		for(int i=0; i<mib.length; ++i) {
			mib[i].setImg(null);
			mib[i].repaint();
		}
	}

	@Override
	public void run() {
		while(time>0) {
			try {
				Thread.sleep(1000);
			}catch(Exception e) {}
			time--;
			time_lb.setText("�ð� : 0"+time+"��");
		}
		isEnable = false;
		buttonSetting();
		buttonClear();
	}
}

public class Test01 {
	public static void main(String[] args) {
		MyFrame01 mf = new MyFrame01("frame����");
	}
}
