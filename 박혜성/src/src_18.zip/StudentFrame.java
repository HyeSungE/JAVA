package student;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.List;

public class StudentFrame extends Frame implements ActionListener{
	private TextArea ta = new TextArea();
	private Button bt1 = new Button("�Է�");
	private Button bt2 = new Button("����");
	private Button bt3 = new Button("����");
	private Button bt4 = new Button("����");
	
	private MyInputDialog md = new MyInputDialog(this, "�л��Է�", true);
	
	private String ta_str = new String("�� �� �� ��\n-----------------\n");
	private Panel p = new Panel();
	
	private StudentPro pro = new StudentProImpl();
	
	public void view_ta() {
		ta.setText(ta_str);
		List<Student> list = pro.output();
		Collections.sort(list);
		for(Student st : list) {
			ta.append(st.getName() + "\t" + st.getKor()+"\t"+ 
					st.getEng()+ "\t" + st.getTot() + "\t" + st.getRank() + "\n");
		}
	}
	
	public void init() {
		this.setLayout(new BorderLayout());
		ta.setFont(new Font("", Font.PLAIN, 20));
		ta.setEditable(false);
		view_ta();
		this.add("Center", ta);
		this.add("East", p);
		p.setPreferredSize(new Dimension(100, 300));
		p.setLayout(new GridLayout(4, 1));
		p.add(bt1);	bt1.addActionListener(this);
		p.add(bt2);	bt2.addActionListener(this);
		p.add(bt3);	bt3.addActionListener(this);
		p.add(bt4);	bt4.addActionListener(this);
		md.ok_bt.addActionListener(this);
		md.cen_bt.addActionListener(this);
	}
	
	public StudentFrame(String title) {
		super(title);
		this.init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==bt1) {
			md.setVisible(true);
		}else if (e.getSource()==bt2) {

		}else if (e.getSource()==bt3) {
			
		}else if (e.getSource()==bt4) {
			System.exit(0);
		}else if (e.getSource()==md.ok_bt) {
			String name = md.getName();
			int kor = md.getKor();
			int eng = md.getEng();
			pro.input(name, kor, eng);
			md.clearData();
			md.setVisible(false);
			view_ta();
		}else if (e.getSource()==md.cen_bt) {
			md.clearData();
			md.setVisible(false);
		}
	}
	
	public static void main(String[] args) {
		new StudentFrame("��������");
	}
}
