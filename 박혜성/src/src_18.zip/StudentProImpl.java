package student;
import java.util.*;

public class StudentProImpl implements StudentPro{

	private List<Student> list;
	
	public StudentProImpl() {
		list = new ArrayList<>();
	}

	@Override
	public void input(String name, int kor, int eng) {
		Student input = new Student(name, kor, eng);
		list.add(input);
	}

	public void rank() {
		for(Student i : list) {
			i.clearRank();
			for(Student j : list) {
				if (i.getTot() < j.getTot()) {
					i.plusRank();
				}
			}
		}
	}
	
	@Override
	public List<Student> output() {
		rank();
		Collections.sort(list);
		return list;
	}

	@Override
	public Student getStudent(String name) {
		for(Student st : list) {
			if (st.getName().trim().equals(name)) {
				return st;
			}
		}
		return null;
	}

	@Override
	public void edit(Student edit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Student delete) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void exit() {
		System.exit(0);
	}
}









