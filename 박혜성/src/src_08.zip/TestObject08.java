
public class TestObject08 {
	public static void main(String[] args) {
		for(int i=1; i<10; ++i) {
			System.out.print(fibonachi(i) + " , ");
		}
		System.out.println(fibonachi(10));
	}
	
	public static int fibonachi(int n) {
		if (n<=2) return 1;
		return fibonachi(n-2) + fibonachi(n-1);
	}
}
