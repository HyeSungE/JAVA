import java.util.*;

public class TestObject07 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("2�� �������� �Է� : ");
		int su = in.nextInt();
		
		int res = result(su);
		System.out.printf("%d�� ��� %d\n", su, res);
	}
	
	public static int result(int n) {
		if (n==0) return 1;
		return 2 * result(n-1);
	}
}
