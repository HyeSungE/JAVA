import java.util.*;
import java.io.*;

public class TestObject03 {
	public static void main(String[] args) throws IOException {
		int su1 = input();
		int su2 = input();
		char op = (char)System.in.read();
		
		int res = 0;
		switch(op) {
		case '+' :
			res = add(su1, su2); break;
		case '-' :
			res = min(su1, su2); break;
		case '*' :
			res = mul(su1, su2); break;
		case '/' :
			res = div(su1, su2); break;
		default :
			System.out.println("�߸��Է��ϼ̽��ϴ�.");
			System.exit(0);
		}
		System.out.printf("%d %c %d = %d\n", su1, op, su2, res);
	}
	
	public static int add(int a, int b) {
		return a+b;
	}
	public static int min(int a, int b) {
		if (b>a) return b-a;
		return a-b;
	}
	public static int mul(int a, int b) {
		return a*b;
	}
	public static int div(int a, int b) {
		if (b==0) b=1;
		return a/b;
	}
	
	public static int input() {
		Scanner in = new Scanner(System.in);
		System.out.print("���� �Է� : ");
		int su = in.nextInt();
		return su;
	}
}
