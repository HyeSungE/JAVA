import java.awt.*;
import java.awt.event.*;

class MyFrame04 extends Frame implements ActionListener{
	private MenuBar mb = new MenuBar();
	private Menu file = new Menu("����");
	private Menu help = new Menu("����");
	private MenuItem f_open = new MenuItem("���� ����");
	private MenuItem f_save = new MenuItem("���� ����");
	private MenuItem f_exit = new MenuItem("����");
	private MenuItem h_ver = new MenuItem("���� ����");
	
	private Dialog dlg = new Dialog(this, "��������", true);
	private Label dlg_bl = new Label("���� 1.0 �Դϴ�.", Label.CENTER);
	private Button dlg_bt = new Button("Ȯ��");
	private Panel dlg_sou_p = new Panel();
	
	public void init() {
		dlg.setLayout(new BorderLayout());
		dlg_bl.setFont(new Font("", Font.BOLD, 30));
		dlg.add("Center", dlg_bl);
		dlg.add("South", dlg_sou_p);
		dlg_sou_p.setLayout(new FlowLayout(FlowLayout.CENTER));
		dlg_sou_p.add(dlg_bt);	dlg_bt.addActionListener(this);
		
		this.setMenuBar(mb);
		mb.add(file);
		file.add(f_open); f_open.addActionListener(this);
		file.add(f_save); f_save.addActionListener(this);
		file.addSeparator();
		file.add(f_exit); f_exit.addActionListener(this);
		mb.add(help);	
		help.add(h_ver);  h_ver.addActionListener(this);
	}
	public MyFrame04(String title) {
		super(title);
		this.init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == f_open) {
			FileDialog fdlg = new FileDialog(this, "���Ͽ���", FileDialog.LOAD);
			fdlg.setVisible(true);
		}else if (e.getSource() == f_save) {
			FileDialog fdlg = new FileDialog(this, "��������", FileDialog.SAVE);
			fdlg.setVisible(true);
		}else if (e.getSource() == f_exit) {
			System.exit(0);
		}else if (e.getSource() == h_ver) {
			dlg.setBounds(300, 300, 300, 150);
			dlg.setResizable(false);
			dlg.setVisible(true);
		}else if (e.getSource() == dlg_bt) {
			dlg.setVisible(false);
		}
		
	}
}

public class Test04 {
	public static void main(String[] args) {
		MyFrame04 mf = new MyFrame04("frame����");
	}
}
