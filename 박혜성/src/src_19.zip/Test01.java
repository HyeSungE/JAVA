//�迭 9*9�� ����� ��ź 10���� ����� ��½����ִ� ���α׷�

public class Test01 {
	static int arr[][] = new int[9][9];
	
	public static void boomSetting(int a, int b) {
		int minI = a-1; if (minI<0) minI = 0;
		int maxI = a+1; if (maxI>8) maxI = 8;
		int minJ = b-1; if (minJ<0) minJ = 0;
		int maxJ = b+1; if (maxJ>8) maxJ = 8;
		for(int i=minI; i<=maxI; ++i) {
			for(int j=minJ; j<=maxJ; ++j) {
				if (arr[i][j] != 10) arr[i][j]++;
			}
		}
	}
	public static void main(String[] args) {
		for(int i=0; i<10; ++i) {
			int x, y;
			do {
				x = (int)(Math.random()*9);
				y = (int)(Math.random()*9);
			}while(arr[x][y] != 0);
			
			arr[x][y] = 10;
			boomSetting(x, y);
		}
		
		for(int i=0; i<9; ++i) {
			for(int j=0; j<9; ++j) {
				if (arr[i][j] == 10) {
					System.out.print("��ź\t");
				}else {
					System.out.print(arr[i][j]+"\t");
				}
			}
			System.out.println();
		}
	}
}
