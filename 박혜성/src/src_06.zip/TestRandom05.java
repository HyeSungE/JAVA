
public class TestRandom05 {
	public static void main(String[] args) {
		int arr[] = new int[45];
		//1���� ������ -> arr[0]�� ����, 2���� ������ -> arr[1]�� ���� .....
		int rank[] = new int[45];
	
		for(int k=1; k<=10000; ++k) {
			int com[] = new int[6];
			for(int i=0; i<com.length; ++i) {
				com[i] = (int)(Math.random()*45) + 1;
				for(int j=0; j<i; ++j) {
					if (com[i] == com[j]) {
						i--;
						break;
					}
				}
			}
			for(int i=0; i<6; ++i) {
				arr[com[i]-1]++;
			}
		}
		
		for(int i=0; i<arr.length; ++i) {
			for(int j=0; j<arr.length; ++j) {
				if (arr[i] < arr[j]) {
					rank[i]++;
				}
			}
		}
		
		System.out.print("�̹��� �ζ� ��ȣ : ");
		for(int i=0; i<6; ++i) {
			for(int j=0; j<rank.length; ++j) {
				if (rank[j] == i) {
					System.out.print(j+1+" ");
				}
			}
		}
	}
}










