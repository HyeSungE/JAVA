import java.util.*;

public class TestArray01 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int[] arr = new int[10];
		for(int i=0; i<arr.length; ++i) {
			System.out.print(i+1+"��° ���� �Է� : ");
			arr[i] = in.nextInt();
		}
		
		Arrays.sort(arr);
		/*bubble sort
		for(int i=1; i<arr.length; ++i) {
			for(int j=0; j<arr.length-i; ++j) {
				if (arr[j] > arr[j+1]) {
					int imsi = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = imsi;
				}
			}
		}
		
		/*select sort
		for(int i=0; i<arr.length-1; ++i) {
			for(int j=i+1; j<arr.length; ++j) {
				if (arr[i] > arr[j]) {
					int imsi = arr[i];
					arr[i] = arr[j];
					arr[j] = imsi;
				}
			}
		}
		*/
		System.out.print("���ĵ� �� : ");
		for(int i=0; i<arr.length-1; ++i) {
			System.out.print(arr[i] + " , ");
		}
		System.out.println(arr[arr.length-1]);
	}
}










