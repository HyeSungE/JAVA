package member;

public interface MemberPro {
	public void input();
	public void output();
	public void edit();
	public void delete();
	public void exit();
}
