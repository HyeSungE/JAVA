import java.util.*;
public class Test02 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("���ڿ��� �Է� : ");
		String str = in.nextLine();
		
		int alpha[] = new int[27];
		//a - alpha[0], b - alpha[1], ... z - alpha[25], ��Ÿ - alpha[26]
		for(int i=0; i<str.length(); ++i) {
			char ch = str.charAt(i);
			if (ch>=65 && ch<=90) {//�빮�� A ~ Z �����Դϱ�?
				alpha[ch-65]++;
			}else if (ch>=97 && ch<=122) {//�ҹ��� a ~ z �����Դϱ�?
				alpha[ch-97]++;
			}else {
				alpha[26]++;
			}
		}
		for(int i=0; i<alpha.length-1; ++i) {
			if (alpha[i] == 0) continue;
			System.out.println((char)(i+97) + " ==> " + alpha[i]);
		}
		if (alpha[26] != 0) {
			System.out.println("��Ÿ ==> " + alpha[26]);
		}
		/*
		for(int i=str.length()-1; i>=0; --i) {
			System.out.print(str.charAt(i));
		}
		System.out.println();
		*/
	}
}
