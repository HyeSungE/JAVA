import java.net.*;
import java.util.Scanner;

public class Test07 {
	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(System.in);
		System.out.print("1.�ð�  2.��¥  3.�ð�����¥  4.���� : ");
		int select = in.nextInt();
		String data = String.valueOf(select);
		
		InetAddress ia = InetAddress.getByName("localhost");
		DatagramPacket dp = new DatagramPacket(data.getBytes(), data.getBytes().length, ia, 12345);
		DatagramSocket ds = new DatagramSocket(12346);
		DatagramPacket dp2 = new DatagramPacket(new byte[65508], 65508);
		ds.send(dp);
		ds.receive(dp2);
		ds.close();
		System.out.println("��� : " + new String(dp2.getData()).trim());
	}
}




