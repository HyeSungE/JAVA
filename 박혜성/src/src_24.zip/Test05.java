import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;

class MyFrame05 extends JFrame implements ActionListener, KeyListener, Runnable{
	
	private JTextArea jta = new JTextArea();
	private JLabel lb = new JLabel("�޼��� : ", JLabel.RIGHT);
	private JTextField jtf = new JTextField();
	private JButton jbt = new JButton("����");
	private JScrollPane jsp = new JScrollPane(jta,
			ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER
			//ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS
			);
	
	private JPanel jp = new JPanel();
	
	private DatagramPacket send_dp = null, receive_dp = null;
	private DatagramSocket ds = null;
	private InetAddress ia = null;
	
	public void init() {
		Container con = this.getContentPane();
		con.setLayout(new BorderLayout());
		jta.setEditable(false);
		con.add("Center", jsp);
		con.add("South", jp);
		jp.setLayout(new BorderLayout());
		jp.add("West", lb);
		jtf.addKeyListener(this);
		jtf.setEnabled(false);
		jp.add("Center", jtf);
		jbt.setEnabled(false);
		jbt.addActionListener(this);
		jp.add("East", jbt);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public MyFrame05(String title) {
		super(title);
		this.init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
		try {
			ds = new DatagramSocket(12345);
			ia = InetAddress.getByName("localhost");
			Thread th = new Thread(this);
			th.start();
			jta.append("������ ���ӵǾ����ϴ�." + "\n");
			jtf.setEnabled(true);
			jbt.setEnabled(true);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			String msg = jtf.getText();
			jtf.setText("");
			send_dp = new DatagramPacket(msg.getBytes(), msg.getBytes().length, ia, 12346);
			try{ds.send(send_dp);}catch(Exception ee) {}
			jta.append("���� ������ �޼��� : " + msg +"\n");
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String msg = jtf.getText();
		jtf.setText("");
		send_dp = new DatagramPacket(msg.getBytes(), msg.getBytes().length, ia, 12346);
		try{ds.send(send_dp);}catch(Exception ee) {}
		jta.append("���� ������ �޼��� : " + msg +"\n");
	}

	@Override
	public void run() {
		try {
			while(true) {
				receive_dp = new DatagramPacket(new byte[65508], 65508);
				ds.receive(receive_dp);
				String msg = new String(receive_dp.getData()).trim();
				jta.append("�������� �� �޼��� : " + msg + "\n");
			}
		}catch(SocketException e) {
			System.out.println("������ ��!!");
			System.exit(0);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

public class Test05 {
	public static void main(String[] args) {
		MyFrame05 mf = new MyFrame05("frame����");
	}
}