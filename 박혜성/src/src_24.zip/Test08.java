import java.net.*;
import java.util.*;
import java.text.*;

public class Test08 {
	public static void main(String[] args) throws Exception {
		DatagramPacket dp = new DatagramPacket(new byte[65508], 65508);
		DatagramSocket ds = new DatagramSocket(12345);
		ds.receive(dp);
		InetAddress ia = dp.getAddress();
		String msg = new String(dp.getData()).trim();
		System.out.println(msg);
		int select = Integer.parseInt(msg);
		Date date = new Date();
		SimpleDateFormat sdf = null;
		switch(select) {
		case 1 : sdf = new SimpleDateFormat("HH:mm:ss"); break;
		case 2 : sdf = new SimpleDateFormat("yy-MM-dd"); break;
		case 3 : sdf = new SimpleDateFormat("yy-MM-dd HH:mm:ss"); break;
		case 4 : System.exit(0);
		}
		String data = sdf.format(date);
		DatagramPacket dp2 = new DatagramPacket(data.getBytes(), 
				data.getBytes().length, ia, 12346);
		ds.send(dp2);
		ds.close();
	}
}




