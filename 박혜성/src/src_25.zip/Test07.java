import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.net.*;
import java.io.*;
//��� ���� ����
class MyFrame07 extends JFrame{
	private String str = new String("�̸�\t\t��ȭ��ȣ\n");
	private JTextArea jta = new JTextArea();
	private JScrollPane jsp = new JScrollPane(jta,
			ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
	private DatagramPacket dp = null;
	private DatagramSocket ds = null;
	private java.util.List<Member> list = new ArrayList<>();
	
	public void init() {
		Container con = this.getContentPane();
		con.setLayout(new BorderLayout());
		jta.setText(str);
		con.add("Center", jsp);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public MyFrame07(String title) {
		super(title);
		this.init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
		try {
			ds = new DatagramSocket(12345);
		}catch(Exception e) {}
		while(true) {
			try {
				dp = new DatagramPacket(new byte[65508], 65508);
				ds.receive(dp);
				ByteArrayInputStream bais = new ByteArrayInputStream(dp.getData());
				ObjectInputStream ois = new ObjectInputStream(bais);
				Member member = (Member)ois.readObject();
				jta.append(member.getName()+"\t\t"+member.getTel()+"\n");
				list.add(member);
			}catch(Exception e) {}
			
		}
	}
}

public class Test07 {
	public static void main(String[] args) {
		MyFrame07 mf = new MyFrame07("frame����");
	}
}
