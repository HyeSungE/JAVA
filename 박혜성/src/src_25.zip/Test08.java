import java.io.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import java.net.*;

class Member implements Serializable{
	private String name;
	private String tel;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
}

class MyFrame08 extends JFrame implements ActionListener{
	//private JDialog input = new JDialog(this, "�Է�", true);
	private JLabel lb = new JLabel("ȸ���Է�", JLabel.CENTER);
	private JLabel name_lb = new JLabel("�̸� : ", JLabel.RIGHT);
	private JTextField name_jtf = new JTextField();
	private JPanel name_p = new JPanel();
	private JLabel tel_lb = new JLabel("���� : ", JLabel.RIGHT);
	private JTextField tel_jtf = new JTextField();
	private JPanel tel_p = new JPanel();
	private JButton jbt1 = new JButton("�Է�");
	private JButton jbt2 = new JButton("���");
	private JPanel button_p = new JPanel();
	
	private DatagramPacket dp;
	private DatagramSocket ds;
	private InetAddress ia;
	
	public void init() {
		Container con = this.getContentPane();
		con.setLayout(new GridLayout(4, 1));
		con.add(lb);
		con.add(name_p);
		name_p.setLayout(new BorderLayout());
		name_p.add("West", name_lb);
		name_p.add("Center", name_jtf);
		con.add(tel_p);
		tel_p.setLayout(new BorderLayout());
		tel_p.add("West", tel_lb);
		tel_p.add("Center", tel_jtf);
		con.add(button_p);
		button_p.setLayout(new FlowLayout(FlowLayout.CENTER));
		button_p.add(jbt1); jbt1.addActionListener(this);
		button_p.add(jbt2); jbt2.addActionListener(this);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public MyFrame08(String title) {
		super(title);
		this.init();
		
		this.setSize(300,200);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
		try {
			ia = InetAddress.getByName("localhost");
			ds = new DatagramSocket();
		}catch(Exception e) {}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==jbt2) {
			name_jtf.setText("");
			tel_jtf.setText("");
		}else if (e.getSource()==jbt1) {
			Member member = new Member();
			member.setName(name_jtf.getText());
			member.setTel(tel_jtf.getText());
			name_jtf.setText("");
			tel_jtf.setText("");
			try {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(baos);
			
				oos.writeObject(member);
				oos.close();
				byte[] by = baos.toByteArray();
				dp = new DatagramPacket(by, by.length, ia, 12345);
				ds.send(dp);
			}catch(Exception ee) {}
		}
	}
}

public class Test08 {
	public static void main(String[] args) {
		MyFrame08 mf = new MyFrame08("frame����");
	}
}
