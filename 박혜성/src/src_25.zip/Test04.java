import java.net.*;

public class Test04 {
	public static void main(String[] args) throws Exception {
		DatagramPacket dp = new DatagramPacket(new byte[65508], 65508);
		DatagramSocket ds = new DatagramSocket(12345);
		
		ds.receive(dp);
		ds.close();
		String str = new String(dp.getData()).trim();
		System.out.println("str = " + str);
	}
}
