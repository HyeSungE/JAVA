import java.net.*;

public class Test02 {
	public static void main(String[] args) throws Exception{
		DatagramPacket dp = new DatagramPacket(new byte[65508], 65508);
		
		MulticastSocket ms = new MulticastSocket(12345);
		InetAddress ia = InetAddress.getByName("224.50.50.50");
		ms.joinGroup(ia);
		ms.receive(dp);
		ms.leaveGroup(ia);
		ms.close();
		
		System.out.println("������ : " + dp.getAddress().getHostAddress());
		System.out.println("���빰 : " + new String(dp.getData()).trim());
	}
}
