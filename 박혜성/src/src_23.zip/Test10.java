import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import javax.swing.*;

class MyFrame08 extends JFrame implements ActionListener, KeyListener, Runnable{
	
	private JTextArea jta = new JTextArea();
	private JLabel lb = new JLabel("�޼��� : ", JLabel.RIGHT);
	private JTextField jtf = new JTextField();
	private JButton jbt = new JButton("����");
	
	private JPanel jp = new JPanel();
	
	private InetAddress ia = null;
	private Socket soc = null;
	private PrintWriter pw = null;
	private BufferedReader br = null;
	
	public void init() {
		Container con = this.getContentPane();
		con.setLayout(new BorderLayout());
		jta.setEditable(false);
		con.add("Center", jta);
		con.add("South", jp);
		jp.setLayout(new BorderLayout());
		jp.add("West", lb);
		jtf.addKeyListener(this);
		jtf.setEnabled(false);
		jp.add("Center", jtf);
		jbt.setEnabled(false);
		jbt.addActionListener(this);
		jp.add("East", jbt);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public MyFrame08(String title) {
		super(title);
		this.init();
		this.setSize(400,300);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xpos = (int)(screen.getWidth()/2) - this.getWidth()/2;
		int ypos = (int)(screen.getHeight()/2) - this.getHeight()/2;
		this.setLocation(xpos, ypos);
		this.setResizable(false);
		
		this.setVisible(true);
		try {
			ia = InetAddress.getByName("localhost");
			soc = new Socket(ia, 12345);
			Thread th = new Thread(this);
			th.start();
			jta.append("������ ���ӵǾ����ϴ�." + "\n");
			pw = new PrintWriter(soc.getOutputStream(), true);
			jtf.setEnabled(true);
			jbt.setEnabled(true);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			String msg = jtf.getText();
			jtf.setText("");
			pw.println(msg);
			pw.flush();
			jta.append("���� ������ �޼��� : " + msg +"\n");
		}	
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String msg = jtf.getText();
		jtf.setText("");
		pw.println(msg);
		pw.flush();
		jta.append("���� ������ �޼��� : " + msg+"\n");
	}

	@Override
	public void run() {
		try {
			br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			while(true) {
				String msg = br.readLine();
				if (msg == null) break;
				jta.append("�������� �� �޼��� : " + msg + "\n");
			}
		}catch(SocketException e) {
			System.out.println("������ ��!!");
			System.exit(0);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

public class Test08 {
	public static void main(String[] args) {
		MyFrame08 mf = new MyFrame08("frame����");
	}
}