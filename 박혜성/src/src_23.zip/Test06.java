import java.net.*;
import java.io.*;
import java.util.*;

public class Test04 {
	public static void main(String[] args) {
		InetAddress ia = null;
		Socket soc = null;
		PrintWriter pw = null;
		BufferedReader br = null;
		Scanner key = new Scanner(System.in);
		try {
			ia = InetAddress.getByName("localhost");
			//�ڱ� �ڽſ��� ����ϱ� : localhost, 127.0.0.1, �ڽ���ip�ּ�
			soc = new Socket(ia, 12345);
			pw = new PrintWriter(new BufferedWriter
							(new OutputStreamWriter(soc.getOutputStream())));
			br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			while(true) {
				System.out.print("���� �޼��� : ");
				String sendMsg = key.next();
				if (sendMsg.equalsIgnoreCase("END")) break;
				pw.println(sendMsg);
				pw.flush();
				String msg = br.readLine();
				System.out.println("�������� �� �޼��� : " + msg);
			}
			soc.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Ŭ���̾�Ʈ ��!!");
	}
}
