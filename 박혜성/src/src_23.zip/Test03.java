import java.net.*;
import java.io.*;

public class Test03 {
	public static void main(String[] args) {
		ServerSocket ss = null;
		Socket soc = null;
		BufferedReader br = null;
		PrintWriter pw = null;
		try {
			ss = new ServerSocket(12345);
			System.out.println("���� �����......");
			soc = ss.accept();
			System.out.println("���� ������ : " + soc.toString());
			br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			pw = new PrintWriter(soc.getOutputStream(), true);
			String msg = br.readLine();
			System.out.println("���� ������ : "+ msg);
			pw.println(msg);
			pw.close();
		}catch(Exception e) {}
	}
}





