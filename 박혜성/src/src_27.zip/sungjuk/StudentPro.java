package sungjuk;

public interface StudentPro {
	public void input();
	public void output();
	public void edit();
	public void delete();
	public void exit();
}
