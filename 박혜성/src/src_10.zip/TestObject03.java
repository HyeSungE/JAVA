import java.util.*;

class Student{
	private String name;
	private int kor;
	private int eng;
	protected int tot;
	private int rank;
	Student(String name, int kor, int eng){
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.tot = kor + eng;
		this.rank = 1;
	}
	public String getName() {
		return name;
	}
	
	public boolean setKor(int kor) {
		if (kor<0 || kor>100) return false;
		this.kor = kor;
		return true;
	}
	public int getKor() {
		return kor;
	}
	public boolean setEng(int eng) {
		if (eng<0 || eng>100) return false;
		this.eng = eng;
		return true;
	}
	public int getEng() {
		return eng;
	}
	public void setTot() {
		tot = kor + eng;
	}
	public int getTot() {
		return tot;
	}
	public int getRank() {
		return rank;
	}
	public void clearRank() {
		rank = 1;
	}
	public void plusRank() {
		rank++;
	}
	
	void disp() {
		System.out.println(name+"���� ������ " + tot +"���̰�, ������ " + rank +"�� �Դϴ�.");
	}
}

class Student2 extends Student{
	private int mat;
	public Student2(String name, int kor, int eng, int mat) {
		super(name, kor, eng);
		this.mat = mat;
		setTot();
	}
	public void setTot() {
		tot = getKor() + getEng() + mat;
	}
	public boolean setMat(int mat) {
		if (mat<0 || mat>100) return false;
		this.mat = mat;
		return true;
	}
	public int getMat() {
		return mat;
	}
}
public class TestObject03 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("�ο����� �Է� : ");
		int inwon = in.nextInt();
		Student2[] st = new Student2[inwon];
		
		//��ü �����ϱ�
		for(int i=0; i<inwon; ++i) {
			System.out.print(i+1+"��° �л� �̸� : ");
			String name = in.next();
			int kor = input("����");
			int eng = input("����");
			int mat = input("����");
			st[i] = new Student2(name, kor, eng, mat);
		}
		
		//��������ϱ�
		for(int i=0; i<inwon; ++i) {
			st[i].clearRank();
			for(int j=0; j<inwon; ++j) {
				if (st[i].getTot() < st[j].getTot()) {
					st[i].plusRank();
				}
			}
		}
		
		//����ϱ�
		for(int i=0; i<inwon; ++i) {
			st[i].disp();
		}
		
	}
	
	public static int input(String str) {
		Scanner in = new Scanner(System.in);
		while(true) {
			System.out.print(str+"������ �Է� : ");
			int sub = in.nextInt();
			if (sub>=0 && sub<=100) return sub;
			System.out.println(str+"������ 0������ 100�� ���̸� �Է��� �ּ���!!");
		}
	}
}













