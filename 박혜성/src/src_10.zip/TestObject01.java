class A01 {
	public String toString() {
		return "A01Ŭ�����Դϴ�.";
	}
	
}
public class TestObject01 {
	public static void main(String[] args) {
		A01 ap = new A01();
		
		System.out.println("ap.getClass = " + ap.getClass());
		System.out.println("ap.toString = " + ap.toString());
		System.out.println("ap = " + ap);
		
		String name = new String("ȫ�浿");
		String name2 = name;
		
		System.out.println("name.toString = " + name2);
	}
}







