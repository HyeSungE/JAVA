package RentCarProgrm;

public class sales {
	private int num;
	private int memNum;
	private int carNum;
	private int carPrice;
	private String day;
	//������
	public sales() {
	}
	public sales(int memNum, int carNum,int carPrice,String day) {
		this.memNum=memNum;
		this.carNum=carNum;
		this.carPrice=carPrice;
		this.day=day;
	}
	public sales(int num, int memNum, int carNum,
			int carPrice, String day) {
		this(memNum,carNum,carPrice,day);
		this.num=num;
	}
	//getter & setter
	public int getMemNum() {
		return this.memNum;
	}
	public int getCarNum() {
		return this.carNum;
	}
	public int getCarPrice() {
		return this.carPrice;
	}
	public String getDay() {
		return this.day;
	}
	public void setNum(int num) {
		this.num = num;
	}
}
/*
create table salesTable(
num number,
memNum number,
carNum number,
price number,
day varchar2(20))

create sequence salesSeq;
*/