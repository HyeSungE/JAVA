package RentCarProgrm;

public class car { // ������ ���� Ŭ����
	private int num;
	private String name;
	private String carNum;
	private int price;
	private String rentStat;
	//������
	public car() {
	}
	public car(String carName) {
		this.name=carName;
	}
	public car(String name, String carNum, int price) {
		this.name=name;
		this.carNum=carNum;
		this.price=price;
	}
	public car(String name, String carNum,int price,String rentStat) {
		this(name,carNum,price);
		this.rentStat=rentStat;
	}
	public car(int num, String name, String carNum, int price, String rentStat) {
		this(name,carNum,price,rentStat);
		this.num=num;
	}
	//getter & setter
	public int getNum() {
		return this.num;
	}
	public String getName() {
		return this.name;
	}
	public String getCarNum() {
		return this.carNum;
	}
	public int getPrice() {
		return this.price;
	}
	public String getRentStat() {
		return this.rentStat;
	}
	public void setNum(int num) {
		this.num=num;
	}
	
}
