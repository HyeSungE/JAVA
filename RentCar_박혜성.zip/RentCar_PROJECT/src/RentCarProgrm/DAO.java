package RentCarProgrm;
import java.sql.*;
import java.util.*;
import RentCarProgrm.DAO.*;
//�����ͺ��̽��� ������ DAOŬ����
public class DAO {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	
	private String url,user,pass;
	
	public DAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.err.println("����Ŭ ����̹� ���� ����");
		}
		url = "jdbc:oracle:thin:@localhost:1521:xe";
		user = "bigdata01"; pass = "bigdata01";
	}
	//ȸ��DB�� �����ϴ� DAO
	public class memDAO {
		public memDAO() {//������
			try {
				con = DriverManager.getConnection(url, user, pass);
			}catch(SQLException e){}
		}
		public boolean checkAcc(String id,String pw) { //����Ȯ��
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from memTable where memId = ? and memPw = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1,id); ps.setString(2,pw);
				rs=ps.executeQuery();
				ArrayList<member> list = makeArrayList(rs);
				if(!list.get(0).getBanStat().equals("���")) {
					if(list.size()>0) {
						//System.out.println("����!!!!!");
						return true;
					}
					else if(list.size()==0) {
						//System.out.println("����!!!!!");
						return false;
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		public boolean checkId(String id) { //���̵� �ߺ�Ȯ��
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from memTable where memId = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1, id); 
				rs=ps.executeQuery();
				ArrayList<member> list = makeArrayList(rs);
				if(list.size()>0) {
					//System.out.println("2����!!!!!");
					return false;
				}
				else if(list.size()==0) {
					//System.out.println("2����!!!!!");
					return true;
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		public int insertMember(member m) { //ȸ�����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "insert into memTable values(memSeq.nextVal,?,?,?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setString (1,m.getName());
				ps.setString(2,m.getId());
				ps.setString(3,m.getPw());
				ps.setString(4,m.getEmail());
				ps.setString(5,m.getTel());
				ps.setString(6,m.getBanStat());
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("insert ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public int UpdateBanStat(int num,String memBanStat) {//num(����)���� ȸ���� ���� ���� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql=new String();
				if(memBanStat.equals("Ȱ��ȭ")) 
					sql = "update memTable set memBanStat='���' where NUM = ?";
				else	
					sql = "update memTable set memBanStat='Ȱ��ȭ' where NUM = ?";
				ps = con.prepareStatement(sql);
				ps.setInt (1,num);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("UpdateMemBanStat ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public member SearchMem(String id) {//id�� ȸ���� �˻�
			ArrayList<member> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from memTable where memId = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1,id);
				rs=ps.executeQuery();
				while(rs.next()) {
					int num = rs.getInt("num");
					String name = rs.getString("memName");
					id=rs.getString("memId");
					String pw = rs.getString("memPw");
					String email = rs.getString("memEm");
					String tel = rs.getString("memTel");
					String BanStat = rs.getString("memBanStat");
					member member = new member(num,name,id,pw,email,tel,BanStat);
					list.add(member);
				}
				//System.out.println(list.size());
				return list.get(0);
			}catch(Exception e) {}
			return null;
		}
		public ArrayList<member> makeArrayList(ResultSet rs) throws SQLException {// ResultSet�� ArrayList�� ��ȯ
			ArrayList<member> list = new ArrayList<>();
			while(rs.next()) {
				int n = rs.getInt("num");
				String name = rs.getString("memName");
				String id = rs.getString("memId");
				String pw = rs.getString("memPw");
				String email = rs.getString("memEm");
				String tel = rs.getString("memTel");
				//String BanStat = rs.getString("memBanStat");
				member member = new member(name, id,pw,email,tel);
				member.setNum(n);
				list.add(member);
			}
			return list;
		}
		public ArrayList<member> list(){ //admin�� �ƴ� ��ü ȸ���� ArrayList�� ��ȯ
			ArrayList<member> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from memTable where memid != 'admin'";
				ps=con.prepareStatement(sql);
				rs=ps.executeQuery();
				while(rs.next()) {
					int n = rs.getInt("num");
					String name = rs.getString("memName");
					String id = rs.getString("memId");
					String pw = rs.getString("memPw");
					String email = rs.getString("memEm");
					String tel = rs.getString("memTel");
					String banStat = rs.getString("memBanStat");
					member member = new member(n,name,id,pw,email,tel,banStat);
					list.add(member);
				}
			}catch(Exception e) {}
			return list;
		}
		public int UpdateMember(member m,String id) { //�ش�id�� ȸ���� ������ ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql="update memTable set memName=?,memPw=?,memEm=?,memTel=? where memId = ?";
				ps = con.prepareStatement(sql);
				ps.setString (1,m.getName());
				ps.setString (2,m.getPw());
				ps.setString (3,m.getEmail());
				ps.setString (4,m.getTel());
				ps.setString (5,id);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("UpdateMember ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public int deleteMem(String id) {//num(����)���� ȸ���� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "delete from memTable where memId = ?";
				ps = con.prepareStatement(sql);
				ps.setString (1,id);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("deleteMem ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
	}
	//����DB�� �����ϴ� DAO
	public class carDAO{
		public carDAO() {//������
			try {
				con = DriverManager.getConnection(url, user, pass);
			}catch(SQLException e){}
		}
		public int insertCar(car c) {	//�������
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "insert into carTable values(carSeq.nextVal,?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setString (1,c.getName());
				ps.setString(2,c.getCarNum());
				ps.setInt(3,c.getPrice());
				ps.setString(4,c.getRentStat());
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("insert ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		//�����԰����� -> �뿩 ���� ����
		public int deleteCar(String carNum) {////���� ���� -������ȣ�� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "delete from carTable where CARNUM = ?";
				ps = con.prepareStatement(sql);
				ps.setString (1,carNum);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("deleteCar ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public int deleteCar(int num) {////���� ����-num(����)���� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "delete from carTable where NUM = ?";
				ps = con.prepareStatement(sql);
				ps.setInt (1,num);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("deleteCar ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public int UpdateRentStat(int num,String carRentStat) {//num(����)���� ������ ��Ʈ���� ���θ� ����
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql=new String();
				if(carRentStat.equals("����")) 
					sql = "update carTable set carRentStat='�Ұ���' where NUM = ?";
				else	
					sql = "update carTable set carRentStat='����' where NUM = ?";
				ps = con.prepareStatement(sql);
				ps.setInt (1,num);
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("UpdateRentStat ���� �� ���� �߻�!!");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public boolean checkCarNum(String carNum) { //���� ��ȣ �ߺ�Ȯ��
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from carTable where carNum = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1, carNum);
				ps.executeQuery();
				rs=ps.executeQuery();
				ArrayList<car> list = makeArrayList(rs);
				if(list.size()>0) {
					//System.out.println("����!!!!!");
					return false;
				}
				else if(list.size()==0) {
					//System.out.println("����!!!!!");
					return true;
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		public car searchCar(int num) {//���� �������� ������ �˻��Ͽ� car�� ����
			ArrayList<car> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from carTable where num = ?";
				ps=con.prepareStatement(sql);
				ps.setInt(1, num);
				rs=ps.executeQuery();
				while(rs.next()) {
					String name = rs.getString("carName");
					String carNum = rs.getString("carNum");
					int price = rs.getInt("carPrice");
					String rentStat = rs.getString("carRentStat");
					car car = new car(num,name,carNum,price,rentStat);
					list.add(car);
				}
			}catch(Exception e) {}
			return list.get(0);
		}
		public ArrayList<car> makeArrayList(ResultSet rs) throws SQLException {//ResultSet�� ArrayList�� ��ȯ
			ArrayList<car> list = new ArrayList<>();
			while(rs.next()) {
				int n = rs.getInt("num");
				String carName = rs.getString("carName");
				String carNum = rs.getString("carNum");
				int carPrice = rs.getInt("carPrice");
				String carRentStat = rs.getString("carRentStat");
				car car = new car(carName, carNum,carPrice,carRentStat);
				car.setNum(n);
				list.add(car);
				//System.out.println(list.size());
			}
			return list;
		}
		public ArrayList<car> list(){//��ü ������ ArrayList�� ��ȭ
			ArrayList<car> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select num,carName,carNum,carPrice,carRentStat from carTable";
				ps=con.prepareStatement(sql);
				rs=ps.executeQuery();
				while(rs.next()) {
					int n = rs.getInt("num");
					String name = rs.getString("carName");
					String carNum = rs.getString("carNum");
					int price = rs.getInt("carPrice");
					String rentStat = rs.getString("carRentStat");
					car car = new car(name, carNum,price,rentStat);
					car.setNum(n);
					list.add(car);
					//System.out.println(list.size());
				}
				
			}catch(Exception e) {}
			return list;
		}
		public ArrayList<car> list(String carRentStat){//���� �뿩 ���¿� ���� ���� ����Ʈ�� ������
			ArrayList<car> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from carTable where carRentStat = ?";
				ps=con.prepareStatement(sql);
				ps.setString(1, carRentStat);
				rs=ps.executeQuery();
				while(rs.next()) {
					int num = rs.getInt("num");
					String carName = rs.getString("carName");
					String carNum = rs.getString("carNum");
					int carPrice = rs.getInt("carPrice");
					carRentStat = rs.getString("carRentStat");
					car car = new car(num,carName,carNum,carPrice,carRentStat);
					list.add(car);
					//System.out.println(list.size());
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			return list;
		}
	}
	//����DB�� �����ϴ� DAO
	public class salDAO{
		public salDAO() {//������
			try {
				con = DriverManager.getConnection(url, user, pass);
			}catch(SQLException e){}
		}
		public int insertSales(sales s) {//rent�� �̷���� �� �������̺��� ��� 
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "insert into salesTable values (salesSeq.nextval,?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setInt(1,s.getMemNum());
				ps.setInt(2,s.getCarNum());
				ps.setInt(3,s.getCarPrice());
				ps.setString(4,s.getDay());
				int res = ps.executeUpdate();
				return res;
			}catch(SQLException e) {
				System.err.println("insertSales �� ���� �߻� !");
				e.printStackTrace();
			}finally {
				try {
					if (ps != null) ps.close();
					if (con != null) con.close();
				}catch(SQLException e) {}
			}
			return 0;
		}
		public ArrayList<sales> list(int num) {//ȸ��Num�� ���� �������� ������
			ArrayList<sales> list = new ArrayList<>();
			try {
				con = DriverManager.getConnection(url, user, pass);
				String sql = "select * from salesTable where memNum = ?";
				ps=con.prepareStatement(sql);
				ps.setInt(1, num);
				rs=ps.executeQuery();
				while(rs.next()) {
					int num2 = rs.getInt("num");
					int memNum = rs.getInt("memNum");
					int carNum = rs.getInt("carNum");
					int carPrice = rs.getInt("Price");
					String day = rs.getString("day");
					sales sales = new sales(num2,memNum,carNum,carPrice,day);
					list.add(sales);
				}
			}catch(Exception e) {}
			
			return list;
			}
		}
		
	}

