package RentCarProgrm;

public class member {
	private int num;
	private String name;
	private String id;
	private String pw;
	private String email;
	private String tel;
	private String banStat;
	//������
	public member() {
	}
	public member(int memNum) {
		this.num=memNum;
	}
	public member(String name,String id,String pw,String email,String tel) {
		this.name=name;
		this.id=id;
		this.pw=pw;
		this.email=email;
		this.tel=tel;
		this.banStat="Ȱ��ȭ";
	}
	public member(int num, String name, String id,String pw, String email, String tel, String banStat) {
		this.num=num;
		this.name=name;
		this.id=id;
		this.pw=pw;
		this.email=email;
		this.tel=tel;
		this.banStat=banStat;
	}
	//getter & setter
	public int getNum() {
		return this.num;
	}
	public String getBanStat() {
		return this.banStat;
	}	
	public String getName() {
		return this.name;
	}
	public String getId() {
		return this.id;
	}
	public String getPw() {
		return this.pw;
	}
	public String getEmail() {
		return this.email;
	}
	public String getTel() {
		return this.tel;
	}
	public void setNum(int num) {
		this.num=num;
	}
	public void setBanStat(String banStat) {
		this.banStat=banStat;
	}
}
